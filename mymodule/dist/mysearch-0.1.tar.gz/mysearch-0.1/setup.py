from setuptools import setup

setup(
    name='mysearch',
    version='0.1',
    description='some test module',
    author='papryk',
    author_email='test@example.com',
    url='google.com',
    py_modules=['mysearch']
    )
